/*
package com.example.imhumman;

import android.annotation.SuppressLint;
import android.os.StrictMode;
import android.util.Log;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionHelper {
    String ip,db,DBUserNameStr,DBPasswordStr,port;


    @SuppressLint("NewApi")
    public Connection connectionClasss()
    {

        //Host name: 216.172.184.118
        //Database Name: ab54412_human
        //Database Username: ab54412_duha
        //Database Password: ?F!ABF&=phfo


        // Declaring Server ip, username, database name and password
        ip = "216.172.184.118";
        port = "3306";
        db = "ab54412_human";
        DBUserNameStr = "ab54412_duha";
        DBPasswordStr = "?F!ABF&=phfo";
        // Declaring Server ip, username, database name and password


      //  StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
       // StrictMode.setThreadPolicy(policy);
        java.sql.Connection connection = null;
        //String ConnectionURL = null;
        try
        {
            Class.forName("com.mysql.jdbc.Driver").newInstance();

         //  String ConnectionURL = "jdbc:mysql://" + ip +":"+port+"/"+ db ;
                   //+ ";user=" + DBUserNameStr+ ";password=" + DBPasswordStr + ";";
            //connection = DriverManager.getConnection(ConnectionURL);

            connection =  DriverManager.getConnection("jdbc:mysql://216.172.184.118:3306/ab54412_human?" +
                    "user=DBUserNameStr&password=DBPasswordStr");


           // DriverManager.getConnection(ConnectionURL, DBUserNameStr , DBPasswordStr);
            Log.e("error here 0 : ",connection.toString());

//        catch (SQLException ex) {
//            // handle any errors
//            System.out.println("SQLException: " + ex.getMessage());
//            System.out.println("SQLState: " + ex.getSQLState());
//            System.out.println("VendorError: " + ex.getErrorCode());
//

        }  catch (SQLException se)
        {
            Log.e("error here 1 : ", se.getMessage());
        }
        catch (ClassNotFoundException e)
        {
            Log.e("error here 2 : ", e.getMessage());
        }
        catch (Exception e)
        {
            Log.e("error here 3 : ", e.getMessage());
        }
        return connection;
    }
}
*/
