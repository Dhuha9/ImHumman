package com.example.imhumman;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class UserProfile extends AppCompatActivity implements LoginFragment.dialogFragmentListener{
    TextView edt_nameProfile,edt_emailProfile,edt_phoneNoProfile,edt_passwordProfile;
    ImageView ic_name,ic_email,ic_phone_number,ic_password;
    String textFromDialog="default";
    TextView v;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);

        edt_nameProfile=findViewById(R.id.edt_nameProfile);
        edt_emailProfile=findViewById(R.id.edt_emailProfile);
        edt_phoneNoProfile=findViewById(R.id.edt_phoneNoProfile);
        edt_passwordProfile=findViewById(R.id.edt_passwordProfile);

        ic_name=findViewById(R.id.ic_name);
        ic_name.setOnClickListener(setEditedInfo);

        ic_email=findViewById(R.id.ic_email);
        ic_email.setOnClickListener(setEditedInfo);


        ic_phone_number=findViewById(R.id.ic_phone_number);
        ic_phone_number.setOnClickListener(setEditedInfo);

        ic_password=findViewById(R.id.ic_password);
        ic_password.setOnClickListener(setEditedInfo);

    }

    private View.OnClickListener setEditedInfo=new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Toast.makeText(UserProfile.this, ""+ic_name, Toast.LENGTH_LONG).show();
            switch (view.getId()){
                case R.id.ic_name:v=edt_nameProfile;break;
                case R.id.ic_email:v=edt_emailProfile;break;
                case R.id.ic_phone_number:v=edt_phoneNoProfile;break;
                case R.id.ic_password:v=edt_passwordProfile;break;
            }

            showEditDialog();

        }
    };

    private void showEditDialog() {

        LoginFragment dialogFragment = new LoginFragment();
        dialogFragment.show(getSupportFragmentManager(), "profile");
    }


    @Override
    public void applyText(String txt) {
       v.setText(txt);
    }
}
