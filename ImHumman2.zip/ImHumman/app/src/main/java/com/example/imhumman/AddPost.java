package com.example.imhumman;

import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.maps.model.LatLng;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class AddPost extends AppCompatActivity implements LoginFragment.dialogFragmentListener {

    ImageView img_phoneNumber, img_photo, img_location, img_post_photo;
    EditText edtContent;
    TextView txt_location, txt_photo, txt_phoneNumber;
    LatLng latLng;


    int PICK_IMAGE_REQUEST = 1;
    int GET_LATLONG = 2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_post);

        img_post_photo = findViewById(R.id.img_post_photo);
        txt_photo = findViewById(R.id.txt_photo);

        txt_phoneNumber = findViewById(R.id.txt_phoneNumber);

        img_location = findViewById(R.id.img_location);
        img_location.setOnClickListener(showMap);

        img_photo = findViewById(R.id.img_photo);
        img_photo.setOnClickListener(showFileChooser);

        txt_location = findViewById(R.id.txt_location);

        img_phoneNumber = findViewById(R.id.img_phoneNumber);
        img_phoneNumber.setOnClickListener(addPhoneNumber);

        edtContent = findViewById(R.id.edtContent);


    }


    private View.OnClickListener showMap = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent intent = new Intent(AddPost.this, MapActivity.class);
            startActivityForResult(intent, GET_LATLONG);

        }
    };

    private void getMapLocation(@Nullable Intent intent) {

        Geocoder geocoder = new Geocoder(getApplicationContext(), Locale.getDefault());
        try {
            List<Address> listAdressess = geocoder.getFromLocation(latLng.latitude, latLng.longitude, 1);
            if (listAdressess != null && listAdressess.size() > 0) {

                //to take part of the list of location info
                String stringAddress = "";

                if (listAdressess.get(0).getLocality() != null) {
                    stringAddress += listAdressess.get(0).getLocality() + " ,";
                }

                if (listAdressess.get(0).getAdminArea() != null) {
                    stringAddress += listAdressess.get(0).getAdminArea() + " ,";
                }
                if (listAdressess.get(0).getCountryName() != null) {
                    stringAddress += listAdressess.get(0).getCountryName();
                }

                txt_location.setText(stringAddress);

            }


        } catch (IOException e) {
            e.printStackTrace();

        }


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.add_post_menu, menu);
        return true;
    }


    View.OnClickListener showFileChooser = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent intent = new Intent();
            intent.setType("image/*");
            intent.setAction(Intent.ACTION_GET_CONTENT);

            startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
        }
    };

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK) {
            if (data != null) {
                img_post_photo.setImageURI(data.getData());
                txt_photo.setText(data.getData().toString());
            }
        } else if (requestCode == GET_LATLONG && resultCode == RESULT_OK) {

            if (data != null && data.getExtras() != null && !data.getExtras().isEmpty()) {

                latLng = data.getExtras().getParcelable("latlng");
                getMapLocation(data);
            }
        }
    }


    private View.OnClickListener addPhoneNumber = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            LoginFragment dialogFragment = new LoginFragment();
            dialogFragment.show(getSupportFragmentManager(), "phone");

        }
    };

    @Override
    public void applyText(String txt) {
        txt_phoneNumber.setText(txt);
    }

}

