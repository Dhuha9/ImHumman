package com.example.imhumman;

public class PassingItems {
    private String mUserName;
    private String mPostDetails;
    private int mUserImage;
    private int mPostImage;

    public PassingItems(String UserName,String PostDetails,int UserImage,int PostImage)
    {
        mUserName=UserName;
        mPostDetails=PostDetails;
        mUserImage=UserImage;
        mPostImage=PostImage;
    }
    public String getUserName(){
        return mUserName;
    }
    public String getPostDetails(){
        return mPostDetails;
    }
    public int getUserImage(){
        return mUserImage;
    }
    public int getPostImage(){
        return mPostImage;
    }



}
