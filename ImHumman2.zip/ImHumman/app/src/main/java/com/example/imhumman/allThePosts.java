package com.example.imhumman;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class allThePosts extends AppCompatActivity {

    FloatingActionButton FBtn;
    RecyclerView mRecyclerView;
    RecyclerView.Adapter mAdapter;
    RecyclerView.LayoutManager mLayoutManager;
    DrawerLayout drawer;
    ImageButton imgbt;
    ArrayList<PassingItems> postsList;
    ActionBarDrawerToggle toggle;
    Toolbar toolbar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.all_posts);

        addDrawer();

        FBtn = findViewById(R.id.faB);
        FBtn.setOnClickListener(FBtnClick);

        addDataToList();

        manageRecyclerView();


    }

    private void manageRecyclerView() {

        mRecyclerView = findViewById(R.id.recycle_view);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(this);
        mAdapter = new PostAdapter(postsList,this.getApplicationContext());

        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(mAdapter);
    }

    private void addDrawer() {
        toolbar = findViewById(R.id.toolBar);
        drawer = findViewById(R.id.drawerLayout);
        toggle = new ActionBarDrawerToggle(this, drawer, toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
    }

    private void addDataToList() {
        postsList = new ArrayList<>();
        postsList.add(new PassingItems("انور", "يعاني \"يوسف علي\" ذو 45 عاما  والذي يسكن في حي \n" +
                "تونس ، بغداد\n" +
                " ، من مشكل في صمامات القلب وتكبد الدم في القلب يتطلب إجراء عملية جراحية مستعجلة بأحد المستشفيات \n" +
                "الخاصة بكلفة قدرها 16000000دينار.  \n" +
                "\n" +
                "لذلك فهو توجه لذوي القلوب الرحيمة\n" +
                " ... للمساهمة في", R.drawable.doctorpaper, R.drawable.doctorpaper));
        postsList.add(new PassingItems("انور2", "\"يعاني يوسف علي ذو 45 عاما  والذي يسكن في حي         \"تونس ، بغداد\n" +
                "        \" ، من مشكل في صمامات القلب وتكبد الدم في القلب يتطلب إجراء عملية جراحية مستعجلة بأحد المستشفيات         \"الخاصة بكلفة قدرها 16000000دينار        \"لذلك فهو توجه لذوي القلوب الرحيمة        \" ... للمساهمة في\n" +
                "\n", R.drawable.camera_circle, R.drawable.doctorpaper));
        postsList.add(new PassingItems("انور3", "lkdgoiurojmlkdfjgkldffoodiirisjjjdfkldfjkl", R.drawable.camera_circle, R.drawable.doctorpaper));

    }


    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else
            super.onBackPressed();
    }

    private View.OnClickListener FBtnClick = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent intent = new Intent(allThePosts.this, AddPost.class);
            startActivity(intent);
        }
    };
}
