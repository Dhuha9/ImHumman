package com.example.imhumman;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.maps.model.LatLng;

import java.util.ArrayList;

public class PostAdapter extends RecyclerView.Adapter<PostAdapter.PostViewHolder> {

    private ArrayList<PassingItems> mPostsList;
    private Context mContext;

    public static class PostViewHolder extends RecyclerView.ViewHolder{
         TextView mNameText,mDetailsText,mCallText,mLocationText;
         ImageView mUserImage;
         ImageView mPostImage;
         Context context;


         PostViewHolder(@NonNull View itemView) {
            super(itemView);
            mNameText=itemView.findViewById(R.id.txt_username);
            mDetailsText=itemView.findViewById(R.id.txt_Details);
            mUserImage=itemView.findViewById(R.id.user_image);
            mPostImage=itemView.findViewById(R.id.Details_Image);
            mCallText=itemView.findViewById(R.id.txt_call);
            mLocationText=itemView.findViewById(R.id.txt_location);

        }
    }

    PostAdapter(ArrayList<PassingItems> postsList,Context context) {
        mContext=context;
        mPostsList = postsList;
    }
    @NonNull
    @Override
    public PostViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.single_post,parent,false);
        PostViewHolder pvHolder=new PostViewHolder(v);
        return pvHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull PostViewHolder holder, int position) {
        PassingItems currentItem= mPostsList.get(position);
        holder.mUserImage.setImageResource(currentItem.getUserImage());
        holder.mPostImage.setImageResource(currentItem.getPostImage());
        holder.mNameText.setText(currentItem.getUserName());
        holder.mDetailsText.setText(currentItem.getPostDetails());
        holder.mCallText.setOnClickListener(makeCall);
        holder.mLocationText.setOnClickListener(showLocation);
    }


    @Override
    public int getItemCount() {
        return mPostsList.size();
    }

    private View.OnClickListener makeCall = new View.OnClickListener(){

        @Override
        public void onClick(View view) {

            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:009647712782003"));
            view.getContext().startActivity(intent);
        }
    };

    private View.OnClickListener showLocation=new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent intent = new Intent(mContext, MapActivityDisplayLocation.class);
          // Bundle bundle=new Bundle();
//
           LatLng userLocation = new LatLng(33.312805, 44.361488);
//            bundle.putDouble("latitude", 33.312805);
//            bundle.putDouble("longitude", 44.361488);
           intent.putExtra("latlng",userLocation);

            view.getContext().startActivity(intent);

        }
    };

}
