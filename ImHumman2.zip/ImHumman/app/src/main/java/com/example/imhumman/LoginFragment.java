package com.example.imhumman;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class LoginFragment extends DialogFragment {
    private TextInputEditText edtInput;
    private Button btnAddWritten;
    private dialogFragmentListener listener;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {


        return inflater.inflate(R.layout.fragment, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        super.onViewCreated(view, savedInstanceState);

        btnAddWritten = view.findViewById(R.id.btnAddWritten);
        btnAddWritten.setOnClickListener(LoginListener);

        edtInput = view.findViewById(R.id.edtInput);
        edtInput.addTextChangedListener(passwordWatcher);

    }


    private TextWatcher passwordWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

//            if (charSequence.length() > passwordInputLayout.getCounterMaxLength()) {
//                passwordInputLayout.setError("password is too long");
//            } else {
//                passwordInputLayout.setError(null);
//            }
        }

        @Override
        public void afterTextChanged(Editable editable) {

        }
    };


    private View.OnClickListener LoginListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            String usernameValue = edtInput.getText().toString();

            listener.applyText(usernameValue);
            dismiss();
//            if (usernameValue.equals("")) {
//
//
////                Bundle bundle = new Bundle();
////                bundle.putString("userName", edtInput.getText().toString());
////                setArguments(bundle);
//
//                dismiss();
//
//            } else {
//                Toast.makeText(view.getContext(), "UserName and/or Password are not correct", Toast.LENGTH_LONG).show();
//            }

        }

    };

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
       try {
           listener=(dialogFragmentListener) context;
       }catch (ClassCastException e){
           throw new ClassCastException(context.toString()+ "must implement fragment");
       }


    }

    public interface dialogFragmentListener{
        void applyText(String txt);
    }

}

