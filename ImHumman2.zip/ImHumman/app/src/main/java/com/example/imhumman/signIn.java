package com.example.imhumman;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class signIn extends AppCompatActivity {
     Button btn_SignIn;
     EditText edt_phoneNo,edt_password;
     TextView txt_signNow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        btn_SignIn=findViewById(R.id.btn_signIn);
        btn_SignIn.setOnClickListener(signInListener);

        txt_signNow=findViewById(R.id.txt_signNow);
        txt_signNow.setOnClickListener(signOutListener);

        edt_phoneNo=findViewById(R.id.edt_phoneNo);


        edt_password=findViewById(R.id.edt_password);
    }


    private View.OnClickListener signInListener =new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            if(edt_phoneNo.length()<11)
            {
                //dialog showing error
            }

            String phoneNo=edt_phoneNo.getText().toString();
            String password=edt_password.getText().toString();

            if(phoneNo.equals("") ||password .equals("")){
                //dialog error embty
            }
            /*String query="select * from users where phonenumber="+phoneNo;
            //ResultSet rs=conn.executeQuery(query);
*/
            Intent intent=new Intent(signIn.this,MapActivity.class);
            startActivity(intent);

        }
    };

    View.OnClickListener signOutListener=  new View.OnClickListener() {
        @Override
        public void onClick(View view) {

            Intent intent=new Intent(signIn.this, signUp.class);
            startActivity(intent);

        }
    };

}
