package com.example.imhumman;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class signIn extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);
    }
}
